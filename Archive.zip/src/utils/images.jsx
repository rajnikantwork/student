const LOGO = "/images/logo192.png";
const USERIMG = "/images/user.jpeg";



const LocalImages = {
  LOGO,
  USERIMG,
};

export default LocalImages;
