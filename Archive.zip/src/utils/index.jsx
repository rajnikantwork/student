import LocalImages from './images';

const Utils = {
	LocalImages
};

export default Utils;
