import React from 'react'
import Container from '../../hoc/container/container'

function Signup() {
    return (
        <Container showHeader={false}>
            Sign Up
        </Container>
    )
}

export default Signup